package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "champd")
public class champd  {

	
	@Id
	@Column(name = "codechamp")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int codechamp;
	
	@Column(name = "agriculteur")
	  private String agriculteur;
	
	@Column(name = "caza")
	  private String caza;
	
	@Column(name = "mohafaza")
	  private String mohafaza;
	
	@Column(name = "region")
	  private String region;
	
	@Column(name = "surface")
	  private Long surface;
	  
		@OneToMany(mappedBy = "champd", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
		private Set<sampless> sampless = new HashSet<>();

		public int getCodechamp() {
			return codechamp;
		}

		public void setCodechamp(int codechamp) {
			this.codechamp = codechamp;
		}

		public String getAgriculteur() {
			return agriculteur;
		}

		public void setAgriculteur(String agriculteur) {
			this.agriculteur = agriculteur;
		}

		public String getCaza() {
			return caza;
		}

		public void setCaza(String caza) {
			this.caza = caza;
		}

		public String getMohafaza() {
			return mohafaza;
		}

		public void setMohafaza(String mohafaza) {
			this.mohafaza = mohafaza;
		}

		public String getRegion() {
			return region;
		}

		public void setRegion(String region) {
			this.region = region;
		}

		public long getSurface() {
			return surface;
		}

		public void setSurface(Long surface) {
			this.surface = surface;
		}

		public champd(String agriculteur, String caza, String mohafaza, String region, long surface,
				Set<model.sampless> sampless) {
			super();
			this.agriculteur = agriculteur;
			this.caza = caza;
			this.mohafaza = mohafaza;
			this.region = region;
			this.surface = surface;
			this.sampless = sampless;
		}
}
		




