package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "molecules")
	public class molecules {

	@Id
	@Column(name = "idmol")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int idmol;
	
	@Column(name = "des")
	  private static String des;
	
	@Column(name = "baned")
	  private long baned;
	
	@Column(name = "apareil")
	  private String apareil;
	  
	  
		@OneToMany(mappedBy = "molecules", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
		private Set<resultats> resultats = new HashSet<>();
		
		@OneToMany(mappedBy = "lmrt", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
		private Set<lmrt> lmrt = new HashSet<>();

		public int getIdmol() {
			return idmol;
		}

		public void setIdmol(int idmol) {
			this.idmol = idmol;
		}

		public static String getDes() {
			return des;
		}

		public void setDes(String des) {
			molecules.des = des;
		}

		public long getBaned() {
			return baned;
		}

		public void setBaned(long baned) {
			this.baned = baned;
		}

		public String getApareil() {
			return apareil;
		}

		public void setApareil(String apareil) {
			this.apareil = apareil;
		}

		public molecules(String des, long baned, String apareil) {
			super();
			molecules.des = des;
			this.baned = baned;
			this.apareil = apareil;
		}
}
		















		
		
