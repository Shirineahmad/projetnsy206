package model;



import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "lmrt")

public class lmrt  {
	


		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "idmol")
	    private molecules molecules;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(name = "idprod")
	    private products products;

	    private Long taux;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public molecules getMolecules() {
			return molecules;
		}

		public void setMolecules(molecules molecules) {
			this.molecules = molecules;
		}

		public products getProducts() {
			return products;
		}

		public void setProducts(products products) {
			this.products = products;
		}

		public Long getTaux() {
			return taux;
		}

		public void setTaux(Long taux) {
			this.taux = taux;
		}

		public lmrt(model.molecules molecules, model.products products, Long taux) {
			this.molecules = molecules;
			this.products = products;
			this.taux = taux;
		}
		

		public lmrt() {
	
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "lmrt [molecules=" + molecules + ", products=" + products + "]";
		}
		
	    
}
