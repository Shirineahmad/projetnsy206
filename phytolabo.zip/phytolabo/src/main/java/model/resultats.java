package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "resultats")
public class resultats {
	
	@Id
	@Column(name = "idres")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idres;
	
	@Column(name = "apareil")
	private static String apareil;
	
	@Column(name = "idmol")	
	private int idmol;
	
	@Column(name = "lmrf")	
	private static int lmrf;

	@Column(name = "resultf")	
	private Long resultf;
	
	@Column(name = "regist")	
	private static int regist;
	
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "regist")
    private sampless sampless;

	public int getIdres() {
		return idres;
	}

	public void setIdres(int idres) {
		this.idres = idres;
	}

	public static String getApareil() {
		return apareil;
	}

	public void setApareil(String apareil) {
		this.apareil = apareil;
	}

	public int getIdmol() {
		return idmol;
	}

	public void setIdmol(int idmol) {
		this.idmol = idmol;
	}

	public static int getLmrf() {
		return lmrf;
	}

	public void setLmrf(int lmrf) {
		this.lmrf = lmrf;
	}

	public static int getRegist() {
		return regist;
	}

	public void setRegist(int regist) {
		this.regist = regist;
	}

	public sampless getSampless() {
		return sampless;
	}

	public void setSampless(sampless sampless) {
		this.sampless = sampless;
	}

	public resultats(String apareil, int idmol, int lmrf, int regist, model.sampless sampless) {
		super();
		this.apareil = apareil;
		this.idmol = idmol;
		this.lmrf = lmrf;
		this.regist = regist;
		this.sampless = sampless;
	}
    
    
	
}
