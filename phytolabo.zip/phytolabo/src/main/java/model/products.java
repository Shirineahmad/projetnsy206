package model;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "products")
public class products {
	@Id
	@Column(name = "idprod")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private Long idprod;
	
	@Column(name = "name")
	  private static String name;
	  
	  
		@OneToMany(mappedBy = "products", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
		private Set<sampless> sampless = new HashSet<>();
		
		@OneToMany(mappedBy = "products", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
		private Set<lmrt> lmrt = new HashSet<>();

		public Long getIdprod() {
			return idprod;
		}

		public void setIdprod(Long idprod) {
			this.idprod = idprod;
		}

		public static String getName() {
			return name;
		}

		public void setName(String name) {
			products.name = name;
		}

		public Set<sampless> getSampless() {
			return sampless;
		}

		public void setSampless(Set<sampless> sampless) {
			this.sampless = sampless;
		}

		public Set<lmrt> getLmrt() {
			return lmrt;
		}

		public void setLmrt(Set<lmrt> lmrt) {
			this.lmrt = lmrt;
		}

		public products(Long idprod, String name, Set<model.sampless> sampless, Set<model.lmrt> lmrt) {
			this.idprod = idprod;
			products.name = name;
			this.sampless = sampless;
			this.lmrt = lmrt;
		}

	

		
}
