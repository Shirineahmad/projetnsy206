package model;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "sampless")
public class sampless {
	
	@Id
	@Column(name = "regist")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int regist;
	
	@Column(name = "batch")
	private String batch;
	
	@Column(name = "codechamp")
	private int codechamp;
	
	@Column(name = "dte")
	private String dte;
	
	@Column(name = "exportateur")
	private String exportateur;
	
	@Column(name = "idprod")
	private int idprod;
	
	@Column(name = "pointbord")
	private String pointbord;
	
	@Column(name = "refcargo")
	private String refcargo;
	
	@Column(name = "tocountry")
	private String tocountry;
	
	@OneToMany(mappedBy = "sampless", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<resultats> resultats = new HashSet<>();
	
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "idprod")
    private products products;

	public int getRegist() {
		return regist;
	}

	public void setRegist(int regist) {
		this.regist = regist;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public int getCodechamp() {
		return codechamp;
	}

	public void setCodechamp(int codechamp) {
		this.codechamp = codechamp;
	}

	public String getDte() {
		return dte;
	}

	public void setDte(String dte) {
		this.dte = dte;
	}

	public String getExportateur() {
		return exportateur;
	}

	public void setExportateur(String exportateur) {
		this.exportateur = exportateur;
	}

	public int getIdprod() {
		return idprod;
	}

	public void setIdprod(int idprod) {
		this.idprod = idprod;
	}

	public String getPointbord() {
		return pointbord;
	}

	public void setPointbord(String pointbord) {
		this.pointbord = pointbord;
	}

	public String getRefcargo() {
		return refcargo;
	}

	public void setRefcargo(String refcargo) {
		this.refcargo = refcargo;
	}

	public String getTocountry() {
		return tocountry;
	}

	public void setTocountry(String tocountry) {
		this.tocountry = tocountry;
	}

	public Set<resultats> getResultats() {
		return resultats;
	}

	public void setResultats(Set<resultats> resultats) {
		this.resultats = resultats;
	}

	public products getProducts() {
		return products;
	}

	public void setProducts(products products) {
		this.products = products;
	}

	public sampless(int regist, String batch, int codechamp, String dte, String exportateur, int idprod,
			String pointbord, String refcargo, String tocountry, Set<model.resultats> resultats,
			model.products products) {
		super();
		this.regist = regist;
		this.batch = batch;
		this.codechamp = codechamp;
		this.dte = dte;
		this.exportateur = exportateur;
		this.idprod = idprod;
		this.pointbord = pointbord;
		this.refcargo = refcargo;
		this.tocountry = tocountry;
		this.resultats = resultats;
		this.products = products;
	}
    
    
}