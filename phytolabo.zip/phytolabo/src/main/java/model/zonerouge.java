package model;

public class zonerouge {
	select * from a resultats, b molecules wheree
	b.baned = 1
il faut utiliser jquery
travail a completer 
}
