package controller;

import model.resultats; 
import service.resultatsService; 
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
  
// Annotation 
@RestController
  
// Class 
public class resultatscontroller { 
  
    // Annotation 
    @Autowired private resultatsService resultatsService; 
  
    // Save operation 
    @PostMapping("/resultatss") 
    public resultats saveresultats( 
         @RequestBody resultats resultats) 
    { 
  
        return resultatsService.saveresultats(resultats); 
    } 
  
    // Read operation 
    @GetMapping("/resultatss") 
    public Set<resultats> fetchresultatsList() 
    { 
  
        return resultatsService.fetchresultatsset(); 
    } 
  
    // Update operation 
    @PutMapping("/resultatss/{id}") 
    public resultats 
    updateresultats(@RequestBody resultats resultats, 
                     @PathVariable("id") int idres) 
    { 
  
        return resultatsService.updateresultats( 
            resultats, idres); 
    } 
  
    // Delete operation 
    @DeleteMapping("/resultatss/{id}") 
    public String deleteresultatsById(@PathVariable("id") 
                                       int idres) 
    { 
  
        resultatsService.deleteresultatsById( 
            idres); 
        return "Deleted Successfully"; 
    } 
}