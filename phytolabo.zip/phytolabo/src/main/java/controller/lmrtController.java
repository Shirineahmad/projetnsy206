package controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import model.lmrt;
import service.lmrtservice; 
  
// Annotation 
@RestController
  
// Class 
public class lmrtController { 
  
    // Annotation 
    @Autowired private lmrtservice lmrtService; 
  
    // Save operation 
    @PostMapping("/lmrts") 
    public lmrt savelmrt( 
         @RequestBody lmrt lmrt) 
    { 
  
        return lmrtservice.savelmrt(lmrt); 
    } 
  
    // Read operation 
    @GetMapping("/lmrts") 
    public Set<lmrt> fetchlmrtSet() 
    { 
  
        Set<lmrt> fetchlmrtset = ((Set<lmrt>) lmrtService.fetchlmrtset());
		return fetchlmrtset; 
    } 
  
    // Update operation 
    @PutMapping("/lmrts/{id}") 
    public lmrt 
    updatelmrt(@RequestBody lmrt lmrt, 
                     @PathVariable("id") int lmrtId) 
    { 
  
        return lmrtService.updatelmrt( 
            lmrt, lmrtId); 
    } 
  
    // Delete operation 
    @DeleteMapping("/lmrts/{id}") 
    public String deletelmrtById(@PathVariable("id") 
                                       int lmrtId) 
    { 
  
        lmrtService.deletelmrtById( 
            lmrtId); 
        return "Deleted Successfully"; 
    } 
}