package controller;

import model.molecules; 
import service.moleculesService; 

import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
  
// Annotation 
@RestController
  
// Class 
public class moleculescontroller { 
  
    // Annotation 
    @Autowired private moleculesService moleculesService; 
  
    // Save operation 
    @PostMapping("/moleculess") 
    public molecules savemolecules( 
        @RequestBody molecules molecules) 
    { 
  
        return moleculesService.savemolecules(molecules); 
    } 
  
    // Read operation 
    @GetMapping("/moleculess") 
    public    Set<molecules> fetchmoleculesset() 
    { 
  
        return moleculesService. fetchmoleculesset(); 
    } 
  
    // Update operation 
    @PutMapping("/moleculess/{id}") 
    public molecules 
    updatemolecules(@RequestBody molecules molecules, 
                     @PathVariable("id") int moleculesId) 
    { 
  
        return moleculesService.updatemolecules( 
            molecules, moleculesId); 
    } 
 // Delete operation 
    @DeleteMapping("/moleculess/{id}") 
    public String deletemoleculesById(@PathVariable("id") 
                                       int idmol) 
    { 
  
        moleculesService.deletemoleculesById( 
            idmol); 
        return "Deleted Successfully"; 
    } 
}