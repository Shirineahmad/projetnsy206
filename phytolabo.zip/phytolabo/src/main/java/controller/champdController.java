package controller;

import model.champd;
import model.lmrt;
import service.champdservice;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
  
// Annotation 
@RestController
  
// Class 
public class champdController { 
  
    // Annotation 
    @Autowired private champdservice champdService; 
  
    // Save operation 
    @PostMapping("/champds") 
    public champd savechampd( 
         @RequestBody champd champd) 
    { 
  
        return champdService.savechampd(champd); 
    } 
  
    // Read operation 
    @GetMapping("/champds") 
    public Set<champd> fetchchampdset() 
    { 
    	 Set<champd> fetchchampdset = (Set<champd>) champdService.fetchchampdset();
		return fetchchampdset(); 
  
       // return champdService.fetchchampdset(); 
    } 
  
    // Update operation 
    @PutMapping("/champds/{id}") 
    public champd 
    updatechampd(@RequestBody champd champd, 
                     @PathVariable("id") int champdId) 
    { 
  
        return champdService.updatechampd( 
            champd, champdId); 
    } 
  
    // Delete operation 
    @DeleteMapping("/champds/{id}") 
    public String deletechampdById(@PathVariable("id") 
                                       int champdId) 
    { 
  
        champdService.deletechampdById(champdId); 
        return "Deleted Successfully"; 
    } 
}