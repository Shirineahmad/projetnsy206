package controller;

import model.products; 
import service.productsService; 
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
  
// Annotation 
@RestController
  
// Class 
public class productscontroller { 
  
    // Annotation 
    @Autowired private productsService productsService; 
  
    // Save operation 
    @PostMapping("/products") 
    public products saveproducts( 
         @RequestBody products products) 
    { 
  
        return productsService.saveproducts(products); 
    } 
  
    // Read operation 
    @GetMapping("/products") 
    public Set<products> fetchproductsset() 
    { 
  
        return productsService.fetchproductsset(); 
    } 
  
    // Update operation 
    @PutMapping("/products/{id}") 
    public products 
    updateproducts(@RequestBody products products, 
                     @PathVariable("id") int idprod) 
    { 
  
        return productsService.updateproducts( 
            products, idprod); 
    } 
  
    // Delete operation 
    @DeleteMapping("/productss/{id}") 
    public String deleteproductsById(@PathVariable("id") 
                                       int idprod) 
    { 
  
        productsService.deleteproductsById( 
            idprod); 
        return "Deleted Successfully"; 
    } 
}