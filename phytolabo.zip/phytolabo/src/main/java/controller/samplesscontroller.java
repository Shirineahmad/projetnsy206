package controller;

import model.sampless; 
import service.samplessService; 
import java.util.List; 
import javax.validation.Valid; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.*; 
  
// Annotation 
@RestController
  
// Class 
public class samplessController { 
  
    // Annotation 
    @Autowired private samplessService samplessService; 
  
    // Save operation 
    @PostMapping("/samplesss") 
    public sampless savesampless( 
        @Valid @RequestBody sampless sampless) 
    { 
  
        return samplessService.savesampless(sampless); 
    } 
  
    // Read operation 
    @GetMapping("/samplesss") 
    public List<sampless> fetchsamplessList() 
    { 
  
        return samplessService.fetchsamplessList(); 
    } 
  
    // Update operation 
    @PutMapping("/samplesss/{id}") 
    public sampless 
    updatesampless(@RequestBody sampless sampless, 
                     @PathVariable("id") Long samplessId) 
    { 
  
        return samplessService.updatesampless( 
            sampless, samplessId); 
    } 
  
    // Delete operation 
    @DeleteMapping("/samplesss/{id}") 
    public String deletesamplessById(@PathVariable("id") 
                                       Long samplessId) 
    { 
  
        samplessService.deletesamplessById( 
            samplessId); 
        return "Deleted Successfully"; 
    } 
}