package service;

import model.champd; 
import repository.champrepository;


import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  
import java.util.Set; 
import java.util.Objects; 
  
@Service
public class champdServiceImpl implements champdservice{ 
  
    @Autowired
    private champrepository champrepository; 
  
    // save operation 
    @Override
    public champd savechampd(champd champd) { 
        return champrepository.save(champd); 
    } 
  
    // read operation 
    @Override
    public Set<champd> fetchchampdset() { 
        return (Set<champd>) champrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public champd updatechampd(champd champd, int codechampd) { 
    	champd depDB = champd champrepository.findById(codechampd))).get();  
  
        if (Objects.nonNull(champd.getAgriculteur()) && !"".equalsIgnoreCase(champd.getAgriculteur())) { 
            depDB.setAgriculteur(champd.getAgriculteur()); 
        } 
  
        if (Objects.nonNull(champd.getCaza()) && !"".equalsIgnoreCase(champd.getCaza())) { 
            depDB.setCaza(champd.getCaza()); 
        } 
  
        if (Objects.nonNull(champd.getMohafaza()) && !"".equalsIgnoreCase(champd.getMohafaza())) { 
            depDB.setMohafaza(champd.getMohafaza()); 
        } 
        
        if (Objects.nonNull(champd.getRegion()) && !"".equalsIgnoreCase(champd.getRegion())) { 
            depDB.setRegion(champd.getRegion()); 
        } 
        
        if (Objects.nonNull(champd.getSurface())) { 
            depDB.setSurface(champd.getSurface()); 
        } 
        

        
        return champrepository.save(depDB); 
    } 
  
    private int codechampd() {
		// TODO Auto-generated method stub
		return 0;
	}

	private Object champd(Object findById) {
		// TODO Auto-generated method stub
		return null;
	}

	// delete operation 
    @Override
    public void deletechampdById(int codechampd) { 
        champrepository.deleteById(codechampd); 
    } 
  
}
