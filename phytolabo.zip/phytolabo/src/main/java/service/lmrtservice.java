package service;

import model.lmrt;

import java.util.Set; 
  
public interface lmrtservice { 
    // save operation 
	 lmrt savelmrt(lmrt lmrt);  
  
    // read operation 
    Set<lmrt> fetchlmrtset(); 
  
    // update operation 
    lmrt updatelmrt(lmrt lmrt, int id); 
  
    // delete operation 
    void deletelmrtById(int id);

	

}
