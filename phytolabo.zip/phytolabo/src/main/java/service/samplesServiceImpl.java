package service;

import model.sampless; 
import repository.samplessrepository; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  

import java.util.Objects;
import java.util.Set; 
  
@Service
public abstract class samplesServiceImpl implements samplesService{ 
  
	  private static final int Id = (Integer) null;
	@Autowired
    private samplessrepository samplessrepository; 
  
    // save operation 
    @Override
    public sampless savesampless(sampless sampless) { 
        return samplessrepository.save(sampless); 
    } 
  
    // read operation 
    @Override
    public Set<sampless> fetchsamplessset() { 
        return (Set<sampless>) samplessrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public abstract sampless updatesampless(sampless sampless, int regist);  { 
        sampless depDB = samplessrepository.findById(Id).get(); 
  
        if (Objects.nonNull(sampless.getBatch()) && !"".equalsIgnoreCase(sampless.getBatch())) { 
            depDB.setBatch(sampless.getBatch()); 
        } 
  

  
        model.sampless proddb;
		return samplessrepository.save(proddb); 
    } 
  
    // delete operation 
    @Override
    public void deletesamplessById(int regist) { 
        samplessrepository.deleteById(Id); 
    }

	@Override
	public Set<sampless> fetchsamplessset() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public sampless updatesampless(sampless sampless, int regist) {
		// TODO Auto-generated method stub
		return null;
	} 
  
}
