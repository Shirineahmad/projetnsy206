package service;

import model.resultats; 
import repository.resultatsrepository; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  

import java.util.Objects;
import java.util.Set; 
  
@Service
public abstract class resultatsServiceImpl implements resultatsService{ 
  
	  private static final int Id = (Integer) null;
	@Autowired
    private resultatsrepository resultatsrepository; 
  
    // save operation 
    @Override
    public resultats saveresultats(resultats resultats) { 
        return resultatsrepository.save(resultats); 
    } 
  
    // read operation 
    @Override
    public Set<resultats> fetchresultatsset() { 
        return (Set<resultats>) resultatsrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public abstract resultats updateresultats(resultats resultats, int idres);  { 
        resultats depDB = resultats resultatsrepository.findById(Id).get(); 
  
        if (Objects.nonNull(resultats.getApareil()) && !"".equalsIgnoreCase(resultats.getApareil())) { 
            depDB.setApareil(resultats.getApareil()); 
        } 
  
        if (Objects.nonNull(resultats.getLmrf()))  { 
            depDB.setLmrf(resultats.getLmrf()); 
        } 
        
        if (Objects.nonNull(resultats.getRegist())  { 
            depDB.setRegist(resultats.getRegist()); 
        } 
        model.resultats proddb;
		return resultatsrepository.save(proddb); 
    } 
  
    // delete operation 
    public void deleteresultatsById(int IDres) { 
        resultatsrepository.deleteById(Id); 
    }

	@Override
	public Set<resultats> fetchresultatsset() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public resultats updateresultats(resultats resultats, int idres) {
		// TODO Auto-generated method stub
		return null;
	} 
  
}
