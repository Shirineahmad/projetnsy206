package service;

import model.molecules; 
import repository.moleculesrepository; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  

import java.util.Objects;
import java.util.Set; 
  
@Service
public abstract class moleculesServiceImpl implements moleculesService{ 
  
    private static final int Id = (Integer) null;
	@Autowired
    private moleculesrepository moleculesrepository; 
  
    // save operation 
    @Override
    public molecules savemolecules(molecules molecules) { 
        return moleculesrepository.save(molecules); 
    } 
  
    // read operation 
    @Override
    public Set<molecules>  fetchmoleculesset() { 
        return (Set<molecules>) moleculesrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public abstract molecules updatemolecules(molecules molecules, int idmol);  { 
        molecules depDB = molecules moleculesrepository.findById(Id)).get(); 
  
        if (Objects.nonNull(molecules.getDes()) && !"".equalsIgnoreCase(molecules.getDes())) { 
            depDB.setDes(molecules.getDes()); 
        } 
  

  
        model.molecules proddb;
		return moleculesrepository.save(proddb); 
    } 
  
    // delete operation 
    @Override
    public void deletemoleculesById(int idmol) { 
        moleculesrepository.deleteById(Id); 
    }

	@Override
	public Set<molecules> fetchmoleculesset() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public molecules updatemolecules(molecules molecules, int prodid) {
		// TODO Auto-generated method stub
		return null;
	} 
  
}
