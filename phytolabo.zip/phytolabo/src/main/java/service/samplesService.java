package service;

import model.sampless; 

import java.util.Set; 
  
public interface samplesService { 
    // save operation 
    sampless savesampless(sampless sampless); 
  
    // read operation 
   Set<sampless> fetchsamplessset(); 
  
    // update operation 
	sampless updatesampless(sampless sampless, int regist);
  
    // delete operation 
    void deletesamplessById(int regist);


}
