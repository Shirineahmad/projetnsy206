package service;

import model.products; 
import repository.productsrepository; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  

import java.util.Objects;
import java.util.Set; 
  
@Service
public abstract class productsServiceImpl implements productsService{ 
  
	  private static final int Id = (Integer) null;
	@Autowired
    private productsrepository productsrepository; 
  
    // save operation 
    @Override
    public products saveproducts(products products) { 
        return productsrepository.save(products); 
    } 
  
    // read operation 
    @Override
    public Set<products> fetchproductsset() { 
        return (Set<products>) productsrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public abstract products updateproducts(products products, int idprod);  { 
        products depDB = productsrepository.findById(Id).get(); 
  
        if (Objects.nonNull(products.getName()) && !"".equalsIgnoreCase(products.getName())) { 
            depDB.setName(products.getName()); 
        } 
  

  
        model.products proddb;
		return productsrepository.save(proddb); 
    } 
  
    // delete operation 
    @Override
    public void deleteproductsById(int ID) { 
        productsrepository.deleteById(Id); 
    }

	@Override
	public Set<products> fetchproductsset() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public products updateproducts(products products, int prodid) {
		// TODO Auto-generated method stub
		return null;
	} 
  
}
