package service;

import model.resultats; 

import java.util.Set; 
  
public interface resultatsService { 
    // save operation 
    resultats saveresultats(resultats resultats); 
  
    // read operation 
   Set<resultats> fetchresultatsset(); 
  
    // update operation 
	resultats updateresultats(resultats resultats, int idres);
  
    // delete operation 
    void deleteresultatsById(int idres);


}
