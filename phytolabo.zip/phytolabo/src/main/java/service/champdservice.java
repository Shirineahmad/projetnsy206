package service;

import model.champd;

import java.util.Set; 

  
public interface champdservice { 
    // save operation 
    champd savechampd(champd champd); 
  
    // read operation 
    Set<champd> fetchchampdset(); 
  
    // update operation 
    champd updatechampd(champd champd, int champdId); 
  
    // delete operation 

	void deletechampdById(int codechampd); 
}
