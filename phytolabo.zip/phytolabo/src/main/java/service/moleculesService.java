package service;

import model.molecules; 

import java.util.Set; 
  
public interface moleculesService { 
    // save operation 
    molecules savemolecules(molecules molecules); 
  
    // read operation 
   Set<molecules> fetchmoleculesset(); 
  
    // update operation 
	molecules updatemolecules(molecules molecules, int idmol);
  
    // delete operation 
    void deletemoleculesById(int idmol);




}
