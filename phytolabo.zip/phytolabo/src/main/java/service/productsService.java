package service;

import model.products; 

import java.util.Set; 
  
public interface productsService { 
    // save operation 
    products saveproducts(products products); 
  
    // read operation 
   Set<products> fetchproductsset(); 
  
    // update operation 
	products updateproducts(products products, int idprod);
  
    // delete operation 
    void deleteproductsById(int idprod);






}
