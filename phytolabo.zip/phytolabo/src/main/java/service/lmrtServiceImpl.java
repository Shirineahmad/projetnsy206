package service;

import model.lmrt; 
import repository.lmrtrepository; 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service; 
  

import java.util.Objects;
import java.util.Set; 
  
@Service
public class lmrtServiceImpl implements lmrtservice{ 
  
    private static final String Id = null;
	@Autowired
    private lmrtrepository lmrtrepository; 
  
    // save operation 
    @Override
    public lmrt savelmrt(lmrt lmrt) { 
        return lmrtrepository.save(lmrt); 
    } 
  
    // read operation 
    @Override
    public Set<lmrt> fetchlmrtset() { 
        return (Set<lmrt>) lmrtrepository.findAll(); 
    } 
  
    // update operation 
    @Override
    public lmrt  updatelmrt(lmrt lmrt, int id) { 
        lmrt depDB = lmrt  ((Object)((Object) lmrtrepository.findById(Id)).get(); 
  
        if (Objects.nonNull(lmrt.getTaux()))  { 
            depDB.setTaux(lmrt.getTaux()); 
        } 
  

  
        model.lmrt proddb;
		return lmrtrepository.save(proddb); 
    } 
  
    private lmrt lmrt(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

	// delete operation 
    @Override
    public void deletelmrtById(int ID) { 
        lmrtrepository.deleteById(Id); 
    }




}
