package repository;

import model.champd;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface champrepository {
	
	@Repository


	public interface champdRepository extends CrudRepository<champd, Integer> {

	}

	public champd save(champd champd);

	public Set<champd> findAll();

	public Object findById(int codechampd);

	public void deleteById(int codechampd);

}
