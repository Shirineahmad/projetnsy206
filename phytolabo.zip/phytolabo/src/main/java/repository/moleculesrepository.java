package repository;

import model.molecules;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface moleculesrepository {
	
	@Repository


	public interface moleculesRepository extends CrudRepository<molecules, Integer> {

	}

	public molecules save(molecules molecules);

	public Set<molecules> findAll();

	public molecules findById(int idmol);

	public void deleteById(int id);

}
