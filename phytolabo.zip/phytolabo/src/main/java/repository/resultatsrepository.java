package repository;

import model.resultats;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface resultatsrepository {
	
	@Repository


	public interface resultatsRepository extends CrudRepository<resultats, Integer> {

	}

	public resultats save(resultats resultats);

	public Set<resultats> findAll();

	public Object findById(int id);

	public void deleteById(int id);

}
