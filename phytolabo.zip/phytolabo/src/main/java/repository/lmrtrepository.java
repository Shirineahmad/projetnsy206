package repository;

import model.lmrt;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface lmrtrepository {
	
	@Repository


	public interface lmrtRepository extends CrudRepository<lmrt, Integer> {

	}

	public lmrt save(lmrt lmrt);

	public Set<lmrt> findAll();

	public Object findById(int id);

	public void deleteById(String id);

	public Object findById(String id);

}
