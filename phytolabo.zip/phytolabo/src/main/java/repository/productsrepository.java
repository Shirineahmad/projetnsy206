package repository;

import model.products;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface productsrepository {
	
	@Repository


	public interface productsRepository extends CrudRepository<products, Integer> {

	}

	public products save(products products);

	public Set<products> findAll();

	public void deleteById(int prodid);

}
