package repository;

import model.sampless;

import java.util.Set;

import org.springframework.data.repository.CrudRepository; 
import org.springframework.stereotype.Repository;

public interface samplessrepository {
	
	@Repository


	public interface samplessRepository extends CrudRepository<sampless, Integer> {

	}

	public void deleteById(int id);

	public sampless save(sampless sampless);

	public Set<sampless> findAll();

	public sampless findById(int regist);

}
